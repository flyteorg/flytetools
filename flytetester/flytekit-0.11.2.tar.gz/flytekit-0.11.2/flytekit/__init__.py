from __future__ import absolute_import

import flytekit.plugins

__version__ = '0.11.2'
